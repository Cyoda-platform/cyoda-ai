# Here's the implementation of the processor functions for the `data_ingestion_job`. These functions will include `ingest_raw_data`, `aggregate_raw_data_process`, and `generate_report_process`. I will reuse the existing `ingest_data` function defined in `raw_data_entity/connections/connections.py` and ensure that the outputs are saved to their respective entities.
# 
# ```python
import logging
import asyncio
from app_init.app_init import entity_service
from entity.raw_data_entity.connections.connections import ingest_data as ingest_raw_data_connection
from common.config.config import ENTITY_VERSION

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def ingest_raw_data(meta, data):
    logger.info("Starting data ingestion process.")
    try:
        # Call the reusable ingest_data function
        raw_data = await ingest_raw_data_connection()

        # Save the raw data entity
        raw_data_entity_id = await entity_service.add_item(
            meta["token"], "raw_data_entity", ENTITY_VERSION, raw_data
        )

        # Update the data with the raw data entity ID
        data["raw_data_entity"] = {"technical_id": raw_data_entity_id, "records": raw_data}
        logger.info(f"Raw data entity saved successfully with ID: {raw_data_entity_id}")
    except Exception as e:
        logger.error(f"Error in ingest_raw_data: {e}")
        raise


async def aggregate_raw_data_process(meta, data):
    logger.info("Starting data aggregation process.")
    try:
        # Simulate aggregation logic
        activities = data["raw_data_entity"]["records"]
        aggregated_data = {
            "total_activities": len(activities),
            "completed_activities": sum(1 for activity in activities if activity.get("completed")),
            "pending_activities": sum(1 for activity in activities if not activity.get("completed")),
            "activity_summary": activities,
        }

        # Save the aggregated data entity
        aggregated_data_entity_id = await entity_service.add_item(
            meta["token"], "aggregated_data_entity", ENTITY_VERSION, aggregated_data
        )

        # Update the data with the aggregated data entity ID
        data["aggregated_data_entity"] = {"technical_id": aggregated_data_entity_id}
        logger.info(f"Aggregated data entity saved successfully with ID: {aggregated_data_entity_id}")
    except Exception as e:
        logger.error(f"Error in aggregate_raw_data_process: {e}")
        raise


async def generate_report_process(meta, data):
    logger.info("Starting report generation process.")
    try:
        report_data = {
            "report_id": "report_001",
            "generated_at": "2023-10-01T10:00:00Z",
            "report_title": "Monthly Data Analysis",
            "summary": data["aggregated_data_entity"]["summary"],  # Using the aggregated data
            "distribution_info": {},
        }

        # Save the report entity
        report_entity_id = await entity_service.add_item(
            meta["token"], "report_entity", ENTITY_VERSION, report_data
        )

        # Log the report generation
        logger.info(f"Report entity saved successfully with ID: {report_entity_id}")
    except Exception as e:
        logger.error(f"Error in generate_report_process: {e}")
        raise


# Testing with Mocks
import unittest
from unittest.mock import patch


class TestDataIngestionJob(unittest.TestCase):

    @patch("workflow.ingest_raw_data_connection")
    @patch("app_init.app_init.entity_service.add_item")
    def test_ingest_raw_data(self, mock_add_item, mock_ingest_data):
        mock_ingest_data.return_value = [{"id": 1, "title": "Activity 1", "due_date": "2025-01-22", "completed": False}]
        mock_add_item.return_value = "raw_data_entity_id"

        meta = {"token": "test_token"}
        data = {}

        asyncio.run(ingest_raw_data(meta, data))

        mock_add_item.assert_called_once_with(
            meta["token"], "raw_data_entity", ENTITY_VERSION,
            [{"id": 1, "title": "Activity 1", "due_date": "2025-01-22", "completed": False}]
        )

    @patch("app_init.app_init.entity_service.add_item")
    def test_aggregate_raw_data_process(self, mock_add_item):
        mock_add_item.return_value = "aggregated_data_entity_id"

        meta = {"token": "test_token"}
        data = {
            "raw_data_entity": {
                "technical_id": "raw_data_entity_001",
                "records": [
                    {
                        "id": 1,
                        "title": "Activity 1",
                        "due_date": "2025-01-22T21:36:27.6587562+00:00",
                        "completed": False
                    },
                    {
                        "id": 2,
                        "title": "Activity 2",
                        "due_date": "2025-01-22T22:36:27.6587592+00:00",
                        "completed": True
                    }
                ]
            }
        }

        asyncio.run(aggregate_raw_data_process(meta, data))

        # Ensure the data counts are correct:
        total_activities = len(data["raw_data_entity"]["records"])
        completed_activities = sum(1 for record in data["raw_data_entity"]["records"] if record["completed"])
        pending_activities = total_activities - completed_activities

        mock_add_item.assert_called_once_with(
            meta["token"], "aggregated_data_entity", ENTITY_VERSION,
            {
                "total_activities": total_activities,
                "completed_activities": completed_activities,
                "pending_activities": pending_activities,
                "activity_summary": data["raw_data_entity"]["records"],
            }
        )

    @patch("app_init.app_init.entity_service.add_item")
    def test_generate_report_process(self, mock_add_item):
        mock_add_item.return_value = "report_entity_id"

        meta = {"token": "test_token"}
        data = {
            "raw_data_entity": {
                "technical_id": "raw_data_entity_001",
                "records": [
                    {
                        "id": 1,
                        "title": "Activity 1",
                        "due_date": "2025-01-22T21:36:27.6587562+00:00",
                        "completed": False
                    },
                    {
                        "id": 2,
                        "title": "Activity 2",
                        "due_date": "2025-01-22T22:36:27.6587592+00:00",
                        "completed": True
                    }
                ]
            },
            "aggregated_data_entity": {
                "technical_id": "aggregated_data_entity_001",
                "summary": {
                    "total_activities": 2,
                    "completed_activities": 1,
                    "pending_activities": 1
                }
            }
        }


        asyncio.run(generate_report_process(meta, data))

        mock_add_item.assert_called_once_with(
        meta["token"], "report_entity", ENTITY_VERSION,
        {
            "report_id": "report_001",
            "generated_at": "2023-10-01T10:00:00Z",
            "report_title": "Monthly Data Analysis",
            "summary": data["aggregated_data_entity"]["summary"],
            "distribution_info": {},
        }

    )


    if __name__ == "__main__":
        unittest.main()
        # ```
        #
        # ### Explanation of the Code:
        # 1. **Ingest Raw Data**:
        #    - The `ingest_raw_data` function calls the `ingest_data` function to fetch raw data, saves it to the `raw_data_entity`, and updates the `data` object with the technical ID of the saved entity.
        #
        # 2. **Aggregate Raw Data**:
        #    - The `aggregate_raw_data_process` function processes the ingested data and aggregates it, saving the aggregated data to `aggregated_data_entity`.
        #
        # 3. **Generate Report**:
        #    - The `generate_report_process` function creates a report based on the aggregated data and saves it to `report_entity`.
        #
        # 4. **Unit Tests**:
        #    - Each function includes unittest cases that mock external service calls to test the functionality of the processor functions in isolation. This allows for testing the logic without relying on actual service implementations.
        #
        # This setup ensures that the functions can be tested and reused effectively in future application development.
