# Product Requirements Document (PRD) for Cyoda Design

## Introduction

This document outlines the Cyoda-based application designed to manage data ingestion, aggregation, report generation, and email notification. It explains how the Cyoda design aligns with the specified requirements and provides a comprehensive overview of the concepts involved in the Cyoda entity database, the event-driven architecture, and the various workflows, entities, and actors involved in the system.

## What is Cyoda?

Cyoda is a serverless, event-driven framework that facilitates the management of workflows through entities representing jobs and data. Each entity has a defined state, and transitions between states are governed by events that occur within the system, enabling a responsive and scalable architecture. 

In a Cyoda design, the following key concepts are involved:

- **Entities**: Fundamental components in Cyoda that represent processes or data (e.g., jobs, raw data, reports).
- **Workflows**: Processes tied to each job entity that define state transitions as events occur.
- **Event-Driven Architecture**: An approach that allows the application to respond automatically to changes or events, promoting scalability and efficiency.

## Cyoda Entity Database

The Cyoda entity database consists of several entities that represent the core functionalities required for the application. The design JSON outlines the following entities:

1. **Data Ingestion Job (`data_ingestion_job`)**:
   - **Type**: JOB
   - **Source**: SCHEDULED
   - **Description**: Responsible for ingesting data from specified sources on a scheduled basis (once a day). It transitions through states to complete the ingestion process.

2. **Raw Data Entity (`raw_data_entity`)**:
   - **Type**: EXTERNAL_SOURCES_PULL_BASED_RAW_DATA
   - **Source**: ENTITY_EVENT
   - **Description**: Stores the raw data that has been ingested by the data ingestion job. Its creation is triggered by the corresponding job.

3. **Aggregated Data Entity (`aggregated_data_entity`)**:
   - **Type**: SECONDARY_DATA
   - **Source**: ENTITY_EVENT
   - **Description**: Holds the aggregated data for reporting purposes. It is derived from the raw data entity.

4. **Report Entity (`report_entity`)**:
   - **Type**: SECONDARY_DATA
   - **Source**: ENTITY_EVENT
   - **Description**: Contains the generated report that is sent to the admin via email after aggregation.

### Entity Diagram

```mermaid
graph TD;
    A[data_ingestion_job] -->|triggers| B[raw_data_entity];
    A -->|triggers| C[aggregated_data_entity];
    A -->|triggers| D[report_entity];
```

## Workflow Overview

The workflows in Cyoda define how each job entity operates through a series of transitions. The `data_ingestion_job` includes a singular workflow that outlines the following transition:

- **Start Data Ingestion**: Initiates the data ingestion process from the specified data source, capturing the raw data and marking the state as "data_ingested".

### Sequence Diagram

```mermaid
sequenceDiagram
    participant Admin
    participant Scheduler
    participant Data Ingestion Job
    participant Raw Data Entity
    participant Aggregated Data Entity
    participant Report Entity

    Admin->>Scheduler: Schedule data ingestion job
    Scheduler->>Data Ingestion Job: Trigger data ingestion
    Data Ingestion Job->>Raw Data Entity: Ingest data
    Raw Data Entity-->>Data Ingestion Job: Data ingested
    Data Ingestion Job->>Aggregated Data Entity: Aggregate data
    Aggregated Data Entity-->>Data Ingestion Job: Data aggregated
    Data Ingestion Job->>Report Entity: Generate report
    Report Entity-->>Data Ingestion Job: Report generated
    Data Ingestion Job->>Admin: Send report
```

## Event-Driven Approach

An event-driven architecture is employed to ensure that the application can automatically respond to various triggers without manual intervention. For the specific requirement, the following key events occur:

1. **Data Ingestion**: The data ingestion job is triggered on a scheduled basis, automatically initiating the process of fetching data from the specified source.
2. **Data Aggregation**: Once the data ingestion is complete, an event signals the need to aggregate the ingested data.
3. **Report Generation and Sending**: After the aggregation is finalized, another event triggers the creation of the report and sending it to the admin's email.

### Benefits of the Event-Driven Approach

- **Scalability**: The system can handle multiple ingestion jobs and data processing tasks simultaneously, distributing workload effectively.
- **Efficiency**: With automation in place, the application can operate continuously and reliably without manual oversight.
  
### Actors Involved

- **Admin**: The recipient of the generated reports via email.
- **Scheduler**: Responsible for triggering the data ingestion job as per the defined schedule.
- **Data Ingestion Job**: Central entity managing the workflow of data processing.
- **Raw Data Entity**: Stores the ingested raw data.
- **Aggregated Data Entity**: Holds the processed and aggregated data.
- **Report Entity**: Contains the generated report.

## Conclusion

The Cyoda design effectively aligns with the requirements for creating a robust data processing application. By utilizing the event-driven model, the application efficiently manages state transitions of each entity involved, from data ingestion to report delivery. The outlined entities, workflows, and events comprehensively cover the needs of the application, ensuring a smooth and automated process.

This PRD serves as a foundation for implementation and development, guiding the technical team through the specifics of the Cyoda architecture while providing clarity for users who may be new to the Cyoda framework.